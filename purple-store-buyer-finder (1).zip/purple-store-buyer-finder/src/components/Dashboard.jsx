import { useMemo, useState } from "react";
import { LABELS, copyText, formatTime } from "../lib.js";

const DATE_OPTIONS = [["all", "Semua tanggal"], ["today", "Hari ini"], ["7", "7 hari terakhir"], ["30", "30 hari terakhir"]];
const STATUS_OPTIONS = [["all", "Semua status"], ["baru", "Baru"], ["selesai", "Selesai"], ["diabaikan", "Diabaikan"]];
const STATUS_TEXT = { baru: "Baru", selesai: "Selesai", diabaikan: "Diabaikan" };

function filterItems(items, f) {
  const q = f.q.trim().toLowerCase();
  const startToday = new Date();
  startToday.setHours(0, 0, 0, 0);
  const now = Date.now();
  return items
    .filter((t) => {
      if (f.app !== "all" && t.app !== f.app) return false;
      if (f.keyword !== "all" && !t.matchedKeywords.some((k) => k.toLowerCase() === f.keyword.toLowerCase())) return false;
      if (f.status !== "all" && t.status !== f.status) return false;
      if (f.label !== "all" && t.label !== f.label) return false;
      if (f.date !== "all") {
        const limit = f.date === "today" ? startToday.getTime() : now - Number(f.date) * 86400000;
        if (t.ts < limit) return false;
      }
      if (q && !`${t.userName} ${t.name} ${t.text} ${t.app}`.toLowerCase().includes(q)) return false;
      return true;
    })
    .sort((a, b) => b.ts - a.ts);
}

export default function Dashboard({ items, stats, filters, setFilters, apps, keywords, templates, onStatus, onDelete, onRefresh, loading, api, notify, goSettings }) {
  const shown = useMemo(() => filterItems(items, filters), [items, filters]);
  const set = (key, value) => setFilters((f) => ({ ...f, [key]: value }));

  const STATS = [
    ["🎀", "Total tweet ditemukan", stats.total],
    ["✨", "Tweet baru", stats.baru],
    ["✅", "Selesai ditindaklanjuti", stats.selesai],
    ["🌙", "Diabaikan", stats.diabaikan],
  ];

  return (
    <>
      {api.state === "nokey" && (
        <div className="banner warn">
          <strong>API belum terhubung.</strong> {api.message}{" "}
          <button className="link" onClick={goSettings}>Buka petunjuk</button>
        </div>
      )}
      {api.state === "error" && <div className="banner bad"><strong>Ada masalah:</strong> {api.message}</div>}
      {api.state === "ok" && <div className="banner ok">{api.message}</div>}

      <section className="stats">
        {STATS.map(([icon, label, n]) => (
          <div className="stat" key={label}>
            <span className="stat-icon">{icon}</span>
            <b>{n}</b>
            <span>{label}</span>
          </div>
        ))}
      </section>

      <section className="panel">
        <div className="filters">
          <input className="search" type="search" placeholder="Cari username, isi tweet, atau aplikasi…" value={filters.q} onChange={(e) => set("q", e.target.value)} />
          <select value={filters.app} onChange={(e) => set("app", e.target.value)} aria-label="Filter aplikasi">
            <option value="all">Semua aplikasi</option>
            {apps.map((a) => <option key={a}>{a}</option>)}
          </select>
          <select value={filters.keyword} onChange={(e) => set("keyword", e.target.value)} aria-label="Filter keyword">
            <option value="all">Semua keyword</option>
            {keywords.map((k) => <option key={k.text}>{k.text}</option>)}
          </select>
          <select value={filters.date} onChange={(e) => set("date", e.target.value)} aria-label="Filter tanggal">
            {DATE_OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          <select value={filters.status} onChange={(e) => set("status", e.target.value)} aria-label="Filter status">
            {STATUS_OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          <select value={filters.label} onChange={(e) => set("label", e.target.value)} aria-label="Filter label">
            <option value="all">Semua label</option>
            {Object.entries(LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
          <button className="btn primary" onClick={onRefresh} disabled={loading}>
            {loading ? "Mengambil…" : "🔄 Refresh"}
          </button>
        </div>
        <p className="muted small">Menampilkan {shown.length} dari {items.length} tweet. Refresh hanya jalan saat kamu menekan tombol (atau jika refresh otomatis dinyalakan).</p>
      </section>

      {items.length === 0 && (
        <div className="empty">
          <div className="empty-icon">🧁</div>
          <p>Belum ada tweet.</p>
          <p className="muted small">
            {api.state === "nokey" ? "Hubungkan API dulu di Pengaturan, lalu tekan Refresh." : "Tekan Refresh untuk mulai mencari calon pembeli."}
          </p>
        </div>
      )}
      {items.length > 0 && shown.length === 0 && (
        <div className="empty"><div className="empty-icon">🔍</div><p>Tidak ada tweet yang cocok dengan filter.</p></div>
      )}

      <section className="cards">
        {shown.map((t) => (
          <TweetCard key={t.id} t={t} templates={templates} onStatus={onStatus} onDelete={onDelete} notify={notify} />
        ))}
      </section>
    </>
  );
}

function TweetCard({ t, templates, onStatus, onDelete, notify }) {
  const [tplId, setTplId] = useState(templates[0]?.id || "");
  const [imgFailed, setImgFailed] = useState(false);
  const tpl = templates.find((x) => x.id === tplId) || templates[0];

  async function copyReply() {
    if (!tpl) return notify("Belum ada template. Buat dulu di halaman Template.");
    notify((await copyText(tpl.text)) ? "Balasan disalin ♡" : "Gagal menyalin. Salin manual ya.");
  }

  async function replyWithTemplate() {
    if (!tpl) return notify("Belum ada template. Buat dulu di halaman Template.");
    await copyText(tpl.text); // cadangan jika kolom balasan X tidak terisi otomatis
    // Membuka jendela balasan X dengan teks terisi. Kamu tetap harus menekan kirim sendiri.
    window.open(`https://x.com/intent/post?in_reply_to=${t.id}&text=${encodeURIComponent(tpl.text)}`, "_blank", "noopener");
    notify("Jendela balasan dibuka. Teks juga sudah disalin.");
  }

  function remove() {
    if (window.confirm("Hapus dari dashboard ini?\n\nTweet asli di Twitter/X TIDAK ikut terhapus.")) onDelete(t.id);
  }

  const initial = (t.userName || t.name || "?").charAt(0).toUpperCase();

  return (
    <article className={`card s-${t.status}`}>
      <div className="card-head">
        {t.avatar && !imgFailed
          ? <img className="avatar" src={t.avatar} alt="" loading="lazy" onError={() => setImgFailed(true)} />
          : <div className="avatar fallback" aria-hidden="true">{initial}</div>}
        <div className="who">
          <b>{t.name || (t.userName ? `@${t.userName}` : "Pengguna tidak diketahui")}</b>
          <span className="muted">{t.userName ? `@${t.userName}` : ""} · {formatTime(t.ts)}</span>
        </div>
        <span className={`pill st-${t.status}`}>{STATUS_TEXT[t.status]}</span>
      </div>

      <p className="tweet-text">{t.text}</p>

      <div className="badges">
        <span className={`badge l-${t.label}`}>{LABELS[t.label]}</span>
        <span className="badge app">📱 {t.app}</span>
        {t.matchedKeywords.map((k) => <span key={k} className="badge kw">🔑 {k}</span>)}
      </div>

      <ul className="reasons">
        {t.reasons.map((r, i) => <li key={i}>{r}</li>)}
      </ul>

      <div className="tpl-row">
        <label className="small muted" htmlFor={`tpl-${t.id}`}>Template:</label>
        <select id={`tpl-${t.id}`} value={tplId} onChange={(e) => setTplId(e.target.value)}>
          {templates.length === 0 && <option value="">(belum ada template)</option>}
          {templates.map((x) => <option key={x.id} value={x.id}>{x.text.slice(0, 48)}{x.text.length > 48 ? "…" : ""}</option>)}
        </select>
      </div>

      <div className="actions">
        <a className="btn" href={t.url} target="_blank" rel="noopener noreferrer">🔗 Buka Tweet</a>
        <button className="btn" onClick={copyReply}>📋 Salin Balasan</button>
        <button className="btn primary" onClick={replyWithTemplate}>💬 Balas Pakai Template</button>
        {t.status === "selesai"
          ? <button className="btn" onClick={() => onStatus(t.id, "baru")}>↩️ Jadikan Baru</button>
          : <button className="btn ok" onClick={() => onStatus(t.id, "selesai")}>✅ Tandai Selesai</button>}
        {t.status === "diabaikan"
          ? <button className="btn" onClick={() => onStatus(t.id, "baru")}>↩️ Pulihkan</button>
          : <button className="btn" onClick={() => onStatus(t.id, "diabaikan")}>🌙 Abaikan</button>}
        <button className="btn danger" onClick={remove}>🗑️ Hapus dari dashboard</button>
      </div>
    </article>
  );
}
