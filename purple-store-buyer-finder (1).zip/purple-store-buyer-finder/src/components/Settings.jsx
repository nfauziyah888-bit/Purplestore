import { useState } from "react";
import { formatTime } from "../lib.js";

const STATE_TEXT = {
  unknown: ["Belum diuji", "gray"],
  loading: ["Memproses…", "gray"],
  ok: ["Terhubung", "ok"],
  nokey: ["API belum terhubung", "warn"],
  error: ["Ada masalah", "bad"],
};

// Editor daftar sederhana: tambah & hapus item
function ListEditor({ title, hint, items, onAdd, onRemove, onToggle, prefix = "", protectedItem }) {
  const [text, setText] = useState("");
  const submit = () => {
    const v = text.trim().replace(/^#/, "");
    if (!v) return;
    onAdd(v);
    setText("");
  };
  return (
    <div className="panel">
      <h3>{title}</h3>
      {hint && <p className="muted small">{hint}</p>}
      <div className="chips">
        {items.length === 0 && <span className="muted small">Kosong.</span>}
        {items.map((it) => {
          const name = typeof it === "string" ? it : it.text;
          const off = typeof it !== "string" && !it.active;
          return (
            <span key={name} className={off ? "chip off" : "chip"}>
              {onToggle && (
                <button className="chip-toggle" onClick={() => onToggle(name)} title={off ? "Aktifkan" : "Nonaktifkan"}>
                  {off ? "○" : "●"}
                </button>
              )}
              {prefix}{name}
              {name !== protectedItem && (
                <button className="chip-x" onClick={() => onRemove(name)} aria-label={`Hapus ${name}`}>×</button>
              )}
            </span>
          );
        })}
      </div>
      <div className="add-row">
        <input value={text} placeholder="Tambah baru…" onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
        <button className="btn primary" onClick={submit}>＋ Tambah</button>
      </div>
    </div>
  );
}

export default function Settings({ api, lastSuccess, loading, usage, queries, onTest, onRefresh, onReset, settings, setSettings, hashtags, setHashtags, keywords, setKeywords, apps, setApps }) {
  const [label, tone] = STATE_TEXT[api.state] || STATE_TEXT.unknown;
  const today = usage.date === new Date().toDateString() ? usage.count : 0;
  const maxCost = (settings.maxRequests * 0.003).toFixed(3);
  const num = (key) => (e) => setSettings((s) => ({ ...s, [key]: Number(e.target.value) }));

  return (
    <>
      <section className="panel">
        <h2>🔌 Status API</h2>
        <p><span className={`pill tone-${tone}`}>{label}</span></p>
        <p>{api.message}</p>
        <p className="muted small">
          Terakhir berhasil mengambil data: {lastSuccess ? formatTime(lastSuccess) : "belum pernah"}
        </p>
        <div className="actions">
          <button className="btn primary" onClick={onTest} disabled={loading}>🧪 Test Connection</button>
          <button className="btn" onClick={onRefresh} disabled={loading}>🔄 Refresh</button>
        </div>
        <p className="muted small">
          Test Connection memakai 1 request kecil. Sisa kredit tidak bisa ditampilkan di sini; lihat di dashboard twitterapi.io.
          Request dari dashboard ini hari ini: <b>{today}</b>.
        </p>
      </section>

      <section className="panel">
        <h2>⏱️ Interval & batas biaya</h2>
        <label className="row">
          <input type="checkbox" checked={settings.auto} onChange={(e) => setSettings((s) => ({ ...s, auto: e.target.checked }))} />
          Nyalakan refresh otomatis (hanya jalan saat halaman ini terbuka)
        </label>
        <label className="row">Interval otomatis
          <select value={settings.minutes} onChange={num("minutes")}>
            {[15, 30, 60, 120].map((m) => <option key={m} value={m}>{m} menit{m === 30 ? " (default)" : ""}</option>)}
          </select>
        </label>
        <label className="row">Maksimal request per refresh
          <select value={settings.maxRequests} onChange={num("maxRequests")}>
            {[1, 2, 3, 5].map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
        </label>
        <label className="row">Cari tweet dari
          <select value={settings.days} onChange={num("days")}>
            {[1, 3, 7].map((d) => <option key={d} value={d}>{d} hari terakhir</option>)}
          </select>
        </label>
        <p className="muted small">
          Tiap request mengembalikan maksimal sekitar 20 tweet. Berdasarkan tarif di dokumentasi TwitterAPI.io (sekitar $0.15 per 1.000 tweet,
          minimum $0.00015 per request), satu refresh paling banyak sekitar ${maxCost}. Tarif bisa berubah, jadi cek paket kamu di twitterapi.io.
          Jeda 5,5 detik dipakai antar request agar aman dari rate limit.
        </p>
        <details>
          <summary>Lihat query yang dikirim ({queries.length} query)</summary>
          {queries.length === 0 && <p className="muted small">Belum ada query: tambahkan hashtag dan aktifkan minimal satu keyword.</p>}
          {queries.map((q, i) => <code className="query" key={i}>{q}</code>)}
        </details>
      </section>

      <ListEditor
        title="# Hashtag dipantau" prefix="#" items={hashtags}
        onAdd={(v) => setHashtags((l) => (l.some((x) => x.toLowerCase() === v.toLowerCase()) ? l : [...l, v]))}
        onRemove={(v) => setHashtags((l) => l.filter((x) => x !== v))}
      />
      <ListEditor
        title="🔑 Keyword niat membeli" items={keywords}
        hint="Klik titik untuk mengaktifkan/menonaktifkan. Keyword nonaktif tidak dipakai mencari dan tidak dihitung."
        onAdd={(v) => setKeywords((l) => (l.some((x) => x.text.toLowerCase() === v.toLowerCase()) ? l : [...l, { text: v, active: true }]))}
        onRemove={(v) => setKeywords((l) => l.filter((x) => x.text !== v))}
        onToggle={(v) => setKeywords((l) => l.map((x) => (x.text === v ? { ...x, active: !x.active } : x)))}
      />
      <ListEditor
        title="📱 Daftar aplikasi" items={apps} protectedItem="Lainnya"
        hint="Aplikasi dikenali dari nama yang disebut di isi tweet. 'Lainnya' dipakai jika tidak ada yang cocok."
        onAdd={(v) => setApps((l) => (l.some((x) => x.toLowerCase() === v.toLowerCase()) ? l : [...l.filter((x) => x !== "Lainnya"), v, "Lainnya"]))}
        onRemove={(v) => setApps((l) => l.filter((x) => x !== v))}
      />

      <section className="panel">
        <h2>🔐 Cara memasang API key</h2>
        <ol className="steps">
          <li>Salin API key dari dashboard twitterapi.io.</li>
          <li>Buka Netlify → situs kamu → <b>Site configuration</b> → <b>Environment variables</b> → <b>Add a variable</b>.</li>
          <li>Key: <code>TWITTERAPI_KEY</code>, Value: API key kamu. Simpan.</li>
          <li>Lakukan <b>Deploy</b> ulang (Deploys → Trigger deploy) agar nilainya terbaca.</li>
          <li>Kembali ke sini dan tekan <b>Test Connection</b>.</li>
        </ol>
        <p className="muted small">API key hanya ada di server Netlify. Tidak pernah ditulis di kode, localStorage, atau halaman ini.</p>
      </section>

      <section className="panel">
        <h2>💾 Penyimpanan data</h2>
        <p className="small">
          Semua data (hashtag, keyword, aplikasi, template, status tweet, filter) disimpan di <b>localStorage</b>, yaitu hanya di browser dan perangkat ini.
          Tidak ada sinkronisasi ke HP/laptop lain. Jika data browser dihapus, data ikut hilang. Maksimal 1.000 tweet disimpan.
        </p>
        <button className="btn danger" onClick={() => window.confirm("Hapus SEMUA data lokal dan kembali ke default?") && onReset()}>
          Reset semua data lokal
        </button>
      </section>
    </>
  );
}
