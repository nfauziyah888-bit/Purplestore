import { useState } from "react";
import { copyText, uid } from "../lib.js";

export default function Templates({ templates, setTemplates, notify }) {
  const [draft, setDraft] = useState("");
  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState("");

  function add() {
    const text = draft.trim();
    if (!text) return;
    setTemplates((all) => [...all, { id: uid(), text }]);
    setDraft("");
    notify("Template ditambah ♡");
  }

  function saveEdit() {
    const text = editText.trim();
    if (!text) return;
    setTemplates((all) => all.map((t) => (t.id === editId ? { ...t, text } : t)));
    setEditId(null);
    notify("Template disimpan");
  }

  async function copy(text) {
    notify((await copyText(text)) ? "Template disalin ♡" : "Gagal menyalin. Salin manual ya.");
  }

  function remove(id) {
    if (window.confirm("Hapus template ini?")) setTemplates((all) => all.filter((t) => t.id !== id));
  }

  return (
    <section className="panel">
      <h2>💌 Template Balasan</h2>
      <p className="muted small">
        Di dashboard, pilih template untuk tiap tweet lalu balas manual. Aplikasi ini tidak pernah mengirim balasan otomatis.
        Tips: variasikan kalimat agar tidak terlihat seperti spam.
      </p>

      <div className="add-row">
        <textarea rows={2} placeholder="Tulis template baru…" value={draft} onChange={(e) => setDraft(e.target.value)} />
        <button className="btn primary" onClick={add}>＋ Tambah</button>
      </div>

      <div className="tpl-list">
        {templates.length === 0 && <p className="muted">Belum ada template.</p>}
        {templates.map((t) => (
          <div className="tpl" key={t.id}>
            {editId === t.id ? (
              <>
                <textarea rows={3} value={editText} onChange={(e) => setEditText(e.target.value)} />
                <div className="actions">
                  <button className="btn primary" onClick={saveEdit}>Simpan</button>
                  <button className="btn" onClick={() => setEditId(null)}>Batal</button>
                </div>
              </>
            ) : (
              <>
                <p>{t.text}</p>
                <div className="actions">
                  <button className="btn" onClick={() => copy(t.text)}>📋 Salin</button>
                  <button className="btn" onClick={() => { setEditId(t.id); setEditText(t.text); }}>✏️ Edit</button>
                  <button className="btn danger" onClick={() => remove(t.id)}>🗑️ Hapus</button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
