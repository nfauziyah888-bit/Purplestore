import { useEffect, useMemo, useRef, useState } from "react";
import Dashboard from "./components/Dashboard.jsx";
import Templates from "./components/Templates.jsx";
import Settings from "./components/Settings.jsx";
import {
  DEFAULT_APPS, DEFAULT_FILTERS, DEFAULT_HASHTAGS, DEFAULT_KEYWORDS, DEFAULT_SETTINGS, DEFAULT_TEMPLATES,
  analyze, buildQueries, normalizeTweet, pingBackend, searchTweets, sleep, useLocal,
} from "./lib.js";

const NOKEY_MSG = "API belum terhubung. Isi environment variable TWITTERAPI_KEY di Netlify (lihat halaman Pengaturan).";
const MAX_STORED = 1000; // batas tweet tersimpan di browser

export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [toast, setToast] = useState("");

  // Semua data ini disimpan di localStorage (hanya di browser & perangkat ini)
  const [hashtags, setHashtags] = useLocal("hashtags", DEFAULT_HASHTAGS);
  const [keywords, setKeywords] = useLocal("keywords", DEFAULT_KEYWORDS);
  const [apps, setApps] = useLocal("apps", DEFAULT_APPS);
  const [templates, setTemplates] = useLocal("templates", DEFAULT_TEMPLATES);
  const [tweets, setTweets] = useLocal("tweets", []);
  const [deleted, setDeleted] = useLocal("deleted", []);
  const [filters, setFilters] = useLocal("filters", DEFAULT_FILTERS);
  const [settings, setSettings] = useLocal("settings", DEFAULT_SETTINGS);
  const [lastSuccess, setLastSuccess] = useLocal("lastSuccess", null);
  const [usage, setUsage] = useLocal("usage", { date: "", count: 0 });

  const [api, setApi] = useState({ state: "unknown", message: "Belum dicek." });
  const [loading, setLoading] = useState(false);

  // "latest" selalu berisi data terbaru, agar fungsi async tidak memakai data basi
  const latest = useRef({});
  latest.current = { tweets, deleted, settings, hashtags, keywords };
  const busy = useRef(false);

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2200);
  };

  /* ---- Cek key terpasang saat dibuka (gratis, tidak memakai kredit) ---- */
  useEffect(() => {
    pingBackend()
      .then((r) => setApi(r.configured
        ? { state: "unknown", message: "API key terdeteksi di server. Tekan Test Connection untuk memastikan valid." }
        : { state: "nokey", message: NOKEY_MSG }))
      .catch((e) => setApi({ state: "error", message: e.message }));
  }, []);

  const errorState = (e) => (e.code === "NO_KEY" ? { state: "nokey", message: e.message } : { state: "error", message: e.message });

  const countRequest = () =>
    setUsage((u) => {
      const d = new Date().toDateString();
      return u.date === d ? { date: d, count: u.count + 1 } : { date: d, count: 1 };
    });

  const call = (query, cursor) => {
    countRequest();
    return searchTweets(query, cursor);
  };

  /* ---- Refresh: ambil tweet ---- */
  async function refresh() {
    if (busy.current) return;
    const { settings: s, hashtags: h, keywords: k } = latest.current;
    const queries = buildQueries({ hashtags: h, keywords: k, days: s.days });
    if (!queries.length) {
      setApi({ state: "error", message: "Tambahkan minimal 1 hashtag dan 1 keyword aktif di Pengaturan." });
      return;
    }
    busy.current = true;
    setLoading(true);
    setApi({ state: "loading", message: "Mengambil tweet…" });

    const found = [];
    let budget = s.maxRequests;
    let first = true;
    let failure = null;
    try {
      for (const q of queries) {
        let cursor = "";
        while (budget > 0) {
          if (!first) await sleep(5500); // jeda: akun baru dibatasi 1 request / 5 detik
          first = false;
          budget--;
          const data = await call(q, cursor);
          found.push(...data.tweets);
          if (!data.hasNextPage || !data.nextCursor) break;
          cursor = data.nextCursor;
        }
        if (budget <= 0) break;
      }
    } catch (e) {
      failure = e;
    }

    // Simpan tweet yang berhasil diambil, tanpa duplikat & tanpa yang sudah dihapus
    const { tweets: current, deleted: del } = latest.current;
    const seen = new Set(current.map((t) => t.id));
    const gone = new Set(del);
    const add = [];
    for (const raw of found) {
      const id = String(raw.id);
      if (seen.has(id) || gone.has(id)) continue;
      seen.add(id);
      add.push(normalizeTweet(raw));
    }
    if (add.length) setTweets((prev) => [...add, ...prev].slice(0, MAX_STORED));

    if (failure) {
      setApi(errorState(failure));
    } else {
      setLastSuccess(Date.now());
      setApi({ state: "ok", message: `Selesai: ${add.length} tweet baru dari ${found.length} hasil.` });
    }
    busy.current = false;
    setLoading(false);
  }

  // Refresh otomatis (hanya jalan saat halaman terbuka, dan hanya jika dinyalakan)
  const refreshRef = useRef(refresh);
  refreshRef.current = refresh;
  useEffect(() => {
    if (!settings.auto) return;
    const id = setInterval(() => refreshRef.current(), Math.max(5, settings.minutes) * 60000);
    return () => clearInterval(id);
  }, [settings.auto, settings.minutes]);

  /* ---- Test Connection ---- */
  async function testConnection() {
    if (busy.current) return;
    busy.current = true;
    setLoading(true);
    setApi({ state: "loading", message: "Menguji koneksi…" });
    try {
      const p = await pingBackend();
      if (!p.configured) {
        setApi({ state: "nokey", message: NOKEY_MSG });
      } else {
        const since = Math.floor(Date.now() / 1000) - 3600;
        await call(`"zonauang" since_time:${since}`, ""); // 1 request kecil
        setLastSuccess(Date.now());
        setApi({ state: "ok", message: "Koneksi berhasil. API key valid dan TwitterAPI.io merespons." });
      }
    } catch (e) {
      setApi(errorState(e));
    }
    busy.current = false;
    setLoading(false);
  }

  /* ---- Aksi pada tweet ---- */
  const setStatus = (id, status) => setTweets((all) => all.map((t) => (t.id === id ? { ...t, status } : t)));
  const removeTweet = (id) => {
    setTweets((all) => all.filter((t) => t.id !== id));
    setDeleted((d) => [...new Set([...d, id])]); // supaya tidak muncul lagi saat refresh
  };

  function resetAll() {
    Object.keys(localStorage).filter((k) => k.startsWith("pbf.")).forEach((k) => localStorage.removeItem(k));
    location.reload();
  }

  /* ---- Data turunan ---- */
  const items = useMemo(
    () => tweets.map((t) => ({ ...t, ...analyze(t, { keywords, apps, hashtags }) })),
    [tweets, keywords, apps, hashtags]
  );
  const stats = useMemo(() => ({
    total: tweets.length,
    baru: tweets.filter((t) => t.status === "baru").length,
    selesai: tweets.filter((t) => t.status === "selesai").length,
    diabaikan: tweets.filter((t) => t.status === "diabaikan").length,
  }), [tweets]);
  const queries = useMemo(
    () => buildQueries({ hashtags, keywords, days: settings.days }),
    [hashtags, keywords, settings.days]
  );

  const TABS = [["dashboard", "🍰 Dashboard"], ["templates", "💌 Template"], ["settings", "⚙️ Pengaturan"]];

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="brand-icon">🍇</span>
          <div>
            <h1>Purple Store Buyer Finder</h1>
            <p>Pantau tweet calon pembeli, balas manual dengan sopan ♡</p>
          </div>
        </div>
        <nav className="tabs">
          {TABS.map(([id, label]) => (
            <button key={id} className={tab === id ? "tab on" : "tab"} onClick={() => setTab(id)}>{label}</button>
          ))}
        </nav>
      </header>

      <main>
        {tab === "dashboard" && (
          <Dashboard
            items={items} stats={stats} filters={filters} setFilters={setFilters}
            apps={apps} keywords={keywords} templates={templates}
            onStatus={setStatus} onDelete={removeTweet} onRefresh={refresh}
            loading={loading} api={api} notify={notify} goSettings={() => setTab("settings")}
          />
        )}
        {tab === "templates" && <Templates templates={templates} setTemplates={setTemplates} notify={notify} />}
        {tab === "settings" && (
          <Settings
            api={api} lastSuccess={lastSuccess} loading={loading} usage={usage} queries={queries}
            onTest={testConnection} onRefresh={refresh} onReset={resetAll}
            settings={settings} setSettings={setSettings}
            hashtags={hashtags} setHashtags={setHashtags}
            keywords={keywords} setKeywords={setKeywords}
            apps={apps} setApps={setApps}
          />
        )}
      </main>

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
